#!/bin/sh

cd /home/root/8080
chmod 755 *
./8080 &
/home/root/fanserver/start.sh &