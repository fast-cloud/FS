#!/bin/sh

cd /home/root/fanserver
chmod 755 *
./fanserver